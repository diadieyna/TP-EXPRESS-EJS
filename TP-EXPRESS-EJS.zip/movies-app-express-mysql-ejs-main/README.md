# cloner le projet
# faites 'npm install'
# puis demarrer le projet avec 'npm run dev'
# aller sur 'http://localhost:3000'